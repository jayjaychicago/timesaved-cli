
#!/bin/bash

# Prompt for AWS credentials and region if not provided as arguments
ACCESS_KEY_ID="${1}"
SECRET_ACCESS_KEY="${2}"
REGION="${3}"

if [ -z "${ACCESS_KEY_ID}" ]; then
  read -p "Enter your AWS Access Key ID: " ACCESS_KEY_ID
fi
if [ -z "${SECRET_ACCESS_KEY}" ]; then
  read -p "Enter your AWS Secret Access Key: " SECRET_ACCESS_KEY
fi
if [ -z "${REGION}" ]; then
  read -p "Enter your AWS Region: " REGION
fi

# Find the .tf file in the current directory
TF_FILE=$(find . -maxdepth 1 -name "*.tf" | head -n 1)

if [ -z "$TF_FILE" ]; then
  echo "No .tf file found in the current directory."
  exit 1
fi

# Function to escape only the '/' character
escape_slash() {
  echo "$1" | sed 's///\//g'
}

awk -v access_key="$ACCESS_KEY_ID"     -v secret_key="$SECRET_ACCESS_KEY"     -v region="$REGION"     '{gsub(/ACCESS_KEY_ID_PLACEHOLDER/, access_key); gsub(/SECRET_ACCESS_KEY_PLACEHOLDER/, secret_key); gsub(/REGION_PLACEHOLDER/, region)}1' "$TF_FILE" > "$TF_FILE.tmp" && mv "$TF_FILE.tmp" "$TF_FILE"

# Initialize, plan and apply Terraform
terraform init
terraform plan -out=tfplan
terraform show tfplan
terraform apply -auto-approve
